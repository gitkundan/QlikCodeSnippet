Example on fact table with mixed granularity
============================================

This example contains a mock-up database with order data, customers, countries, 
products and product categories. These five tables are stored in qvd files, and 
if loaded as they are, they should automatically create a snowflake scheme. In 
other words - the key fields are named correctly.

In addition, there is an Excel file with Budget numbers. These are not made on the
same level as the actual numbers. The actual numbers have one record per order line
so these have dates where the budget is lumped together in a year. Further, the 
actual numbers are per product, where the budget is per product category. Finally, 
the actual numbers are per customer, where the budget is per country.

So the two fact tables have different granularity - but you still want to compare them.

Two solutions are created, both using generic keys. The first one uses the budget numbers
as they are, whereas the second takes the yearly budget numbers and distributes the amounts
evenly over the 12 months.

The solutions are delivered as scripts - text files that you need to insert into a QlikView 
document. All paths in the script are relative, so if you save the qvd:s and the excel file 
in the same folder as the qvw, it should work straight away.

HIC

